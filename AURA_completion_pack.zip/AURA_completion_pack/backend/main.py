import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Literal

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from google import genai
from google.genai import types
from pydantic import BaseModel, EmailStr, Field
from pwdlib import PasswordHash
from sqlalchemy import (
    create_engine, String, DateTime, Boolean, ForeignKey, Text, Integer
)
from sqlalchemy.orm import (
    DeclarativeBase, Mapped, mapped_column, sessionmaker, relationship
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("aura")

APP_ENV = os.getenv("APP_ENV", "development").lower()
allowed_origins = [
    item.strip() for item in os.getenv("CORS_ORIGINS", "http://localhost:8081").split(",")
    if item.strip()
]

app = FastAPI(
    title="AURA API",
    description="Student companion API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./aura.db")
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class Student(Base):
    __tablename__ = "students"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class EmailVerification(Base):
    __tablename__ = "email_verifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(320), index=True)
    code_hash: Mapped[str] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    attempts: Mapped[int] = mapped_column(Integer, default=0)


class StudentTask(Base):
    __tablename__ = "student_tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(180))
    notes: Mapped[str] = mapped_column(Text, default="")
    due_at: Mapped[str | None] = mapped_column(String(40), nullable=True)
    category: Mapped[str] = mapped_column(String(40), default="personal")
    completed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Course(Base):
    __tablename__ = "courses"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(160))
    term: Mapped[str] = mapped_column(String(80), default="")


class AcademicItem(Base):
    __tablename__ = "academic_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    course_id: Mapped[int | None] = mapped_column(ForeignKey("courses.id", ondelete="SET NULL"), nullable=True)
    title: Mapped[str] = mapped_column(String(180))
    item_type: Mapped[str] = mapped_column(String(30), default="assignment")
    due_at: Mapped[str | None] = mapped_column(String(40), nullable=True)
    completed: Mapped[bool] = mapped_column(Boolean, default=False)


class Habit(Base):
    __tablename__ = "habits"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(100))
    target_per_day: Mapped[int] = mapped_column(Integer, default=1)
    unit: Mapped[str] = mapped_column(String(30), default="times")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class HabitLog(Base):
    __tablename__ = "habit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    habit_id: Mapped[int] = mapped_column(ForeignKey("habits.id", ondelete="CASCADE"), index=True)
    log_date: Mapped[str] = mapped_column(String(10), index=True)
    amount: Mapped[int] = mapped_column(Integer, default=1)


Base.metadata.create_all(bind=engine)
password_hash = PasswordHash.recommended()
bearer_scheme = HTTPBearer(auto_error=False)
SESSION_LIFETIME_SECONDS = 12 * 60 * 60


def utcnow():
    return datetime.now(timezone.utc)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def b64e(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def get_session_secret() -> bytes:
    secret = os.getenv("AURA_SESSION_SECRET", "")
    if len(secret) < 32:
        raise HTTPException(503, "AURA_SESSION_SECRET must be set to at least 32 characters.")
    return secret.encode()


def create_access_token(student_id: int) -> str:
    now = int(utcnow().timestamp())
    payload = b64e(json.dumps({"sub": str(student_id), "iat": now, "exp": now + SESSION_LIFETIME_SECONDS}, separators=(",", ":"), sort_keys=True).encode())
    sig = hmac.new(get_session_secret(), payload.encode(), hashlib.sha256).digest()
    return payload + "." + b64e(sig)


def current_student(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db=Depends(get_db),
):
    if not credentials or credentials.scheme.lower() != "bearer":
        raise HTTPException(401, "Please log in.")
    try:
        part, signature = credentials.credentials.split(".", 1)
        expected = hmac.new(get_session_secret(), part.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(expected, b64d(signature)):
            raise ValueError("Signature")
        payload = json.loads(b64d(part))
        if int(payload["exp"]) <= int(utcnow().timestamp()):
            raise ValueError("Expired")
        student = db.get(Student, int(payload["sub"]))
        if not student or not student.is_verified or not student.password_hash:
            raise ValueError("Account")
        return student
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "Your session is invalid or expired.")


def code_hash(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


def normalized(email: str) -> str:
    return email.strip().lower()


def allowed_email(email: str) -> bool:
    personal = {"gmail.com", "outlook.com", "hotmail.com", "yahoo.com", "icloud.com", "proton.me"}
    return email.rsplit("@", 1)[-1].lower() not in personal


class RegisterIn(BaseModel):
    email: EmailStr


class VerifyIn(BaseModel):
    email: EmailStr
    code: str = Field(pattern=r"^\d{6}$")


class PasswordIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class ResetIn(BaseModel):
    email: EmailStr
    code: str = Field(pattern=r"^\d{6}$")
    new_password: str = Field(min_length=12, max_length=128)


class ChatLine(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=4000)


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    history: list[ChatLine] = Field(default_factory=list)


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=180)
    notes: str = Field(default="", max_length=4000)
    due_at: str | None = None
    category: str = Field(default="personal", max_length=40)


class TaskPatch(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=180)
    notes: str | None = Field(default=None, max_length=4000)
    due_at: str | None = None
    category: str | None = Field(default=None, max_length=40)
    completed: bool | None = None


class CourseIn(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=160)
    term: str = Field(default="", max_length=80)


class AcademicIn(BaseModel):
    title: str = Field(min_length=1, max_length=180)
    item_type: str = Field(default="assignment", max_length=30)
    due_at: str | None = None
    course_id: int | None = None


class HabitIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    target_per_day: int = Field(default=1, ge=1, le=100)
    unit: str = Field(default="times", max_length=30)


class HabitLogIn(BaseModel):
    log_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    amount: int = Field(default=1, ge=1, le=100)


@app.get("/")
def root():
    return {"name": "AURA API", "status": "running", "version": "1.0.0"}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.post("/auth/register")
def register(data: RegisterIn, db=Depends(get_db)):
    email = normalized(str(data.email))
    if not allowed_email(email):
        raise HTTPException(400, "Please use your university email address.")
    student = db.query(Student).filter(Student.email == email).first()
    if student and student.is_verified:
        raise HTTPException(409, "An account with this email already exists.")
    db.query(EmailVerification).filter(EmailVerification.email == email).delete()
    code = f"{secrets.randbelow(1_000_000):06d}"
    db.add(EmailVerification(email=email, code_hash=code_hash(code), expires_at=utcnow() + timedelta(minutes=10)))
    if not student:
        db.add(Student(email=email))
    db.commit()
    if APP_ENV != "production" and os.getenv("AURA_DEV_MODE", "true").lower() == "true":
        logger.warning("DEV ONLY verification code for %s: %s", email, code)
    return {"message": "If this address is eligible, a verification code will be sent.", "development_mode": APP_ENV != "production"}


@app.post("/auth/verify")
def verify(data: VerifyIn, db=Depends(get_db)):
    email = normalized(str(data.email))
    row = db.query(EmailVerification).filter_by(email=email).order_by(EmailVerification.id.desc()).first()
    if not row or row.attempts >= 5 or utcnow().replace(tzinfo=None) > row.expires_at.replace(tzinfo=None):
        raise HTTPException(400, "Invalid or expired code.")
    if not secrets.compare_digest(row.code_hash, code_hash(data.code)):
        row.attempts += 1
        db.commit()
        raise HTTPException(400, "Invalid or expired code.")
    student = db.query(Student).filter_by(email=email).first()
    if not student:
        raise HTTPException(404, "Registration not found.")
    student.is_verified = True
    db.delete(row)
    db.commit()
    return {"message": "Email verified. Create your AURA password."}


@app.post("/auth/complete-registration")
def complete_registration(data: PasswordIn, db=Depends(get_db)):
    student = db.query(Student).filter_by(email=normalized(str(data.email))).first()
    if not student or not student.is_verified:
        raise HTTPException(403, "Please verify your university email first.")
    if student.password_hash:
        raise HTTPException(409, "An account already exists.")
    student.password_hash = password_hash.hash(data.password)
    db.commit()
    return {"message": "Account created."}


@app.post("/auth/login")
def login(data: LoginIn, db=Depends(get_db)):
    student = db.query(Student).filter_by(email=normalized(str(data.email))).first()
    if not student or not student.is_verified or not student.password_hash or not password_hash.verify(data.password, student.password_hash):
        raise HTTPException(401, "Invalid email or password.")
    return {"access_token": create_access_token(student.id), "token_type": "bearer", "expires_in": SESSION_LIFETIME_SECONDS, "student": {"id": student.id, "email": student.email}}


@app.get("/auth/me")
def me(student=Depends(current_student)):
    return {"id": student.id, "email": student.email, "is_verified": student.is_verified}


@app.post("/auth/forgot-password")
def forgot(data: RegisterIn, db=Depends(get_db)):
    email = normalized(str(data.email))
    student = db.query(Student).filter_by(email=email).first()
    if student and student.is_verified and student.password_hash:
        db.query(EmailVerification).filter_by(email=email).delete()
        code = f"{secrets.randbelow(1_000_000):06d}"
        db.add(EmailVerification(email=email, code_hash=code_hash(code), expires_at=utcnow() + timedelta(minutes=10)))
        db.commit()
        if APP_ENV != "production" and os.getenv("AURA_DEV_MODE", "true").lower() == "true":
            logger.warning("DEV ONLY reset code for %s: %s", email, code)
    return {"message": "If an eligible account exists, a reset code has been issued."}


@app.post("/auth/reset-password")
def reset(data: ResetIn, db=Depends(get_db)):
    email = normalized(str(data.email))
    student = db.query(Student).filter_by(email=email).first()
    row = db.query(EmailVerification).filter_by(email=email).order_by(EmailVerification.id.desc()).first()
    if not student or not row or not student.is_verified or row.attempts >= 5 or utcnow().replace(tzinfo=None) > row.expires_at.replace(tzinfo=None) or not secrets.compare_digest(row.code_hash, code_hash(data.code)):
        if row:
            row.attempts += 1
            db.commit()
        raise HTTPException(400, "Invalid or expired reset code.")
    student.password_hash = password_hash.hash(data.new_password)
    db.delete(row)
    db.commit()
    return {"message": "Password reset. Please log in again."}


@app.get("/tasks")
def list_tasks(student=Depends(current_student), db=Depends(get_db)):
    rows = db.query(StudentTask).filter_by(student_id=student.id).order_by(StudentTask.completed, StudentTask.id.desc()).all()
    return [{"id": x.id, "title": x.title, "notes": x.notes, "due_at": x.due_at, "category": x.category, "completed": x.completed} for x in rows]


@app.post("/tasks")
def create_task(data: TaskIn, student=Depends(current_student), db=Depends(get_db)):
    row = StudentTask(student_id=student.id, **data.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, **data.model_dump(), "completed": row.completed}


@app.patch("/tasks/{task_id}")
def update_task(task_id: int, data: TaskPatch, student=Depends(current_student), db=Depends(get_db)):
    row = db.query(StudentTask).filter_by(id=task_id, student_id=student.id).first()
    if not row:
        raise HTTPException(404, "Task not found.")
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(row, key, value)
    db.commit()
    return {"id": row.id, "title": row.title, "notes": row.notes, "due_at": row.due_at, "category": row.category, "completed": row.completed}


@app.delete("/tasks/{task_id}")
def delete_task(task_id: int, student=Depends(current_student), db=Depends(get_db)):
    row = db.query(StudentTask).filter_by(id=task_id, student_id=student.id).first()
    if not row:
        raise HTTPException(404, "Task not found.")
    db.delete(row); db.commit()
    return {"deleted": True}


@app.get("/courses")
def list_courses(student=Depends(current_student), db=Depends(get_db)):
    return [{"id": x.id, "code": x.code, "name": x.name, "term": x.term} for x in db.query(Course).filter_by(student_id=student.id).all()]


@app.post("/courses")
def create_course(data: CourseIn, student=Depends(current_student), db=Depends(get_db)):
    row = Course(student_id=student.id, **data.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, **data.model_dump()}


@app.delete("/courses/{course_id}")
def delete_course(course_id: int, student=Depends(current_student), db=Depends(get_db)):
    row = db.query(Course).filter_by(id=course_id, student_id=student.id).first()
    if not row: raise HTTPException(404, "Course not found.")
    db.query(AcademicItem).filter_by(student_id=student.id, course_id=course_id).update({"course_id": None})
    db.delete(row); db.commit()
    return {"deleted": True}


@app.get("/academic")
def list_academic(student=Depends(current_student), db=Depends(get_db)):
    rows = db.query(AcademicItem).filter_by(student_id=student.id).order_by(AcademicItem.due_at).all()
    return [{"id": x.id, "course_id": x.course_id, "title": x.title, "item_type": x.item_type, "due_at": x.due_at, "completed": x.completed} for x in rows]


@app.post("/academic")
def create_academic(data: AcademicIn, student=Depends(current_student), db=Depends(get_db)):
    if data.course_id and not db.query(Course).filter_by(id=data.course_id, student_id=student.id).first():
        raise HTTPException(404, "Course not found.")
    row = AcademicItem(student_id=student.id, **data.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, **data.model_dump(), "completed": False}


@app.patch("/academic/{item_id}")
def update_academic(item_id: int, completed: bool, student=Depends(current_student), db=Depends(get_db)):
    row = db.query(AcademicItem).filter_by(id=item_id, student_id=student.id).first()
    if not row: raise HTTPException(404, "Academic item not found.")
    row.completed = completed; db.commit()
    return {"id": row.id, "completed": row.completed}


@app.delete("/academic/{item_id}")
def delete_academic(item_id: int, student=Depends(current_student), db=Depends(get_db)):
    row = db.query(AcademicItem).filter_by(id=item_id, student_id=student.id).first()
    if not row: raise HTTPException(404, "Academic item not found.")
    db.delete(row); db.commit()
    return {"deleted": True}


@app.get("/habits")
def list_habits(student=Depends(current_student), db=Depends(get_db)):
    rows = db.query(Habit).filter_by(student_id=student.id, active=True).all()
    return [{"id": x.id, "name": x.name, "target_per_day": x.target_per_day, "unit": x.unit} for x in rows]


@app.post("/habits")
def create_habit(data: HabitIn, student=Depends(current_student), db=Depends(get_db)):
    row = Habit(student_id=student.id, **data.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, **data.model_dump()}


@app.post("/habits/{habit_id}/log")
def log_habit(habit_id: int, data: HabitLogIn, student=Depends(current_student), db=Depends(get_db)):
    habit = db.query(Habit).filter_by(id=habit_id, student_id=student.id, active=True).first()
    if not habit: raise HTTPException(404, "Habit not found.")
    row = db.query(HabitLog).filter_by(student_id=student.id, habit_id=habit_id, log_date=data.log_date).first()
    if row: row.amount += data.amount
    else:
        row = HabitLog(student_id=student.id, habit_id=habit_id, **data.model_dump())
        db.add(row)
    db.commit()
    return {"habit_id": habit_id, "log_date": data.log_date, "amount": row.amount}


@app.get("/habits/logs")
def habit_logs(log_date: str, student=Depends(current_student), db=Depends(get_db)):
    rows = db.query(HabitLog).filter_by(student_id=student.id, log_date=log_date).all()
    return [{"habit_id": x.habit_id, "amount": x.amount, "log_date": x.log_date} for x in rows]


AURA_INSTRUCTIONS = """
You are AURA, a supportive AI companion for university students.
Be warm, calm, respectful and concise. Listen before offering advice.
Help students manage study, routines and daily life without shame or pressure.
Do not pretend to be human, diagnose conditions, or claim to be a therapist.
Encourage trusted people and qualified professionals when appropriate.
For immediate danger, encourage contacting local emergency services or crisis support.
Do not foster dependence: support the student's agency and real-world relationships.
Be transparent that messages are processed by a cloud AI provider.
"""


@app.post("/chat")
async def chat(data: ChatIn, student=Depends(current_student)):
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise HTTPException(503, "Gemini is not configured. Set GEMINI_API_KEY.")
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    contents = []
    for item in data.history[-10:]:
        contents.append(types.Content(role="user" if item.role == "user" else "model", parts=[types.Part.from_text(text=item.content)]))
    contents.append(types.Content(role="user", parts=[types.Part.from_text(text=data.message)]))
    client = genai.Client(api_key=key)
    try:
        response = await asyncio.to_thread(
            client.models.generate_content,
            model=model,
            contents=contents,
            config=types.GenerateContentConfig(system_instruction=AURA_INSTRUCTIONS, temperature=0.6, max_output_tokens=350),
        )
        if not response.text:
            raise HTTPException(502, "AURA did not receive a response. Please try again.")
        return {"reply": response.text.strip()}
    except HTTPException:
        raise
    except Exception:
        logger.exception("Gemini request failed for student_id=%s", student.id)
        raise HTTPException(502, "AURA is temporarily unavailable. Please try again.")
