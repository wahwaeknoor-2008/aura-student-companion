# AURA completion pack — implementation status

This pack preserves the existing Expo app and replaces the backend with a broader authenticated MVP API.

## Included backend capabilities
- Existing email-registration / code-verification flow (development code is logged; production email delivery is NOT configured).
- Password creation, login, password reset, signed 12-hour sessions.
- Student-owned tasks with create/list/update/complete/delete.
- Student-owned courses.
- Academic deadlines / assignments / quizzes / exams with create/list/update-completion/delete.
- Habits and daily habit logs.
- Authenticated Gemini chat.

## Important: this is not a production launch approval
The uploaded project did not contain the complete planned product. The Expo dashboard was a placeholder: its quick-action cards did not navigate to real task/planner/habit screens. This pack adds the backend APIs but does not falsely claim those frontend screens, calendar sync, push reminders, voice/video, persistent chat history, or end-to-end encryption are complete.

## Before a public launch
1. Configure a real transactional email provider and replace development verification/reset-code logging.
2. Use managed PostgreSQL with backups; do not use ephemeral local SQLite for production.
3. Set `APP_ENV=production`, `AURA_DEV_MODE=false`, `AURA_SESSION_SECRET`, `GEMINI_API_KEY`, `DATABASE_URL`, and exact `CORS_ORIGINS`.
4. Configure HTTPS and platform secrets; never commit `.env`.
5. Add rate limiting, abuse monitoring, account deletion/export, privacy policy, terms, consent flows, and support contact.
6. Test signup, verification, login, reset, cross-account data isolation, CRUD, expired tokens, Gemini quota failures, and mobile builds.
7. Review current dependencies and Expo SDK compatibility before store submission.

## Run locally in Codespaces
Backend:
```bash
cd backend
python -m pip install -r requirements.txt
cp .env.example .env
# Set secrets in Codespaces Secrets or your runtime environment (do not commit .env)
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Frontend (existing Expo app):
```bash
cd mobile
npm install
npx expo start --web
```
The frontend's API URL is still configured in `mobile/App.tsx`; change it to the deployed backend URL for production. Prefer an Expo public environment variable rather than hardcoding it.

## Existing frontend status
The original `mobile/App.tsx` is retained unchanged in this pack to preserve its current auth/chat flow and styling. Its dashboard quick actions are still placeholders and need frontend wiring to the new APIs before calling the product feature-complete.
